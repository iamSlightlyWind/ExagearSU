#!/bin/bash

. /opt/recipe/util/progress.sh

if [ "$(locale -a | grep $LC_ALL)" != "$LC_ALL" ]; then
    progress "-1" "Generating locale..."
    locale-gen --no-archive $LC_ALL
fi

progress "-1" "Launching application..."
export PATH
export TERM
export LD_PRELOAD=/opt/recipe/run/hardlink_to_symlink.so
/opt/recipe/run/sshd &

ed=/tmp/ed

if [ ! -f $ed/ed.conf ]; then
mkdir -p $ed
cp /opt/recipe/ed.conf $ed/ed.conf
fi

. $ed/ed.conf



if [ "${pulse}" = "1" ]; then
    cp "/opt/Driver/dsound.dll.so" "/opt/wine-stable/lib/wine/dsound.dll.so"
    unset AXS_DSOUND_SERVER_PORT
    export PULSE_SERVER="tcp:127.0.0.1:4713"
else 
    cp "/opt/Driver/eltechs_dsound.dll.so" "/opt/wine-stable/lib/wine/dsound.dll.so"
fi

if [ "${hud}" = "1" ]; then
    if [ ! "${GALLIUM_DRIVER}/`xdpyinfo | grep depth:`" = "virpipe/    depth:    16 planes" ]; then
    export GALLIUM_HUD="simple,fps"
    fi
fi


progress "-1" "Pulse=${pulse}/Hud=${hud}"

eval "$@"
