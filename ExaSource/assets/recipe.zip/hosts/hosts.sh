COREFONTS_DOWNLOAD_HOST=http://downloads.sourceforge.net/project/corefonts/the%20fonts/final
#COREFONTS_DOWNLOAD_HOST=http://d2.eltechs.com/corefonts/
DOTNET40_DOWNLOAD_HOST=http://download.lenovo.com/ibmdl/pub/pc/pccbbs/thinkvantage_en/
#DOTNET40_DOWNLOAD_HOST=http://d2.eltechs.com/dotnet40/
